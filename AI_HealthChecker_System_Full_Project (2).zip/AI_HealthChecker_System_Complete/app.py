import os
import sqlite3
from datetime import datetime
from flask import Flask, render_template, request, redirect, session, url_for, flash

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "ai_healthcare_secret_key")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "ai_healthcare.db")

# Optional MySQL configuration. SQLite is used by default so the project runs
# without XAMPP/MySQL. Set USE_MYSQL=1 and install mysql-connector-python
# when you want to use MySQL.
USE_MYSQL = os.environ.get("USE_MYSQL", "0") == "1"

SYMPTOMS = [
    "fever", "headache", "cough", "fatigue", "sore_throat",
    "runny_nose", "body_pain", "nausea", "vomiting", "diarrhea",
    "stomach_pain", "joint_pain", "rash", "shortness_of_breath"
]

DISEASE_PROFILES = {
    "Common Cold": {"fever":1, "headache":1, "cough":1, "runny_nose":2, "sore_throat":2, "fatigue":1},
    "Influenza": {"fever":3, "headache":2, "cough":2, "body_pain":2, "fatigue":2, "sore_throat":1},
    "Migraine": {"headache":4, "nausea":2, "vomiting":2, "fatigue":1},
    "Gastroenteritis": {"nausea":3, "vomiting":3, "diarrhea":3, "stomach_pain":2, "fever":1, "fatigue":1},
    "Allergy": {"runny_nose":3, "cough":1, "sore_throat":1, "rash":2},
    "Viral Fever": {"fever":3, "headache":2, "body_pain":2, "fatigue":2, "nausea":1},
    "Musculoskeletal Pain": {"joint_pain":3, "body_pain":2, "fatigue":1, "headache":1},
    "Respiratory Infection": {"cough":3, "fever":2, "shortness_of_breath":2, "sore_throat":1, "fatigue":1},
}

def get_db():
    if USE_MYSQL:
        try:
            import mysql.connector
            return mysql.connector.connect(
                host=os.environ.get("MYSQL_HOST", "localhost"),
                user=os.environ.get("MYSQL_USER", "root"),
                password=os.environ.get("MYSQL_PASSWORD", ""),
                database=os.environ.get("MYSQL_DATABASE", "ai_healthcare")
            )
        except Exception:
            pass
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def execute(sql, params=(), fetch=False, many=False):
    conn = get_db()
    try:
        cur = conn.cursor()
        if many:
            cur.executemany(sql, params)
        else:
            cur.execute(sql, params)
        rows = cur.fetchall() if fetch else None
        conn.commit()
        return rows
    finally:
        conn.close()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS appointments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        doctor TEXT NOT NULL,
        appointment_date TEXT NOT NULL,
        appointment_time TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS reports (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        symptoms TEXT NOT NULL,
        prediction TEXT NOT NULL,
        created_at TEXT NOT NULL
    )""")
    conn.commit()
    conn.close()

def predict_condition(selected):
    selected = set(selected)
    best_name, best_score = "General Viral Illness", 0
    for name, profile in DISEASE_PROFILES.items():
        score = sum(weight for symptom, weight in profile.items() if symptom in selected)
        # Small coverage bonus for matching several profile symptoms.
        coverage = sum(1 for symptom in profile if symptom in selected)
        score += coverage * 0.25
        if score > best_score:
            best_name, best_score = name, score
    if not selected:
        return "Insufficient symptom information"
    return best_name

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm_password", "")
        if not name or not email or not password:
            flash("Please complete all required fields.", "danger")
            return render_template("register.html")
        if password != confirm:
            flash("Passwords do not match.", "danger")
            return render_template("register.html")
        try:
            execute(
                "INSERT INTO users (name,email,password,created_at) VALUES (?,?,?,?)",
                (name, email, password, datetime.now().isoformat(timespec="seconds"))
            )
        except Exception as e:
            if "UNIQUE" in str(e).upper():
                flash("An account with this email already exists.", "warning")
            else:
                flash("Registration could not be completed.", "danger")
            return render_template("register.html")
        flash("Registration successful. Please log in.", "success")
        return redirect(url_for("login"))
    return render_template("register.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        rows = execute("SELECT * FROM users WHERE email=? AND password=?", (email, password), True)
        if rows:
            user = rows[0]
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            session["user_email"] = user["email"]
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/dashboard")
def dashboard():
    if "user_id" not in session:
        return redirect(url_for("login"))
    appointments = execute(
        "SELECT * FROM appointments WHERE user_id=? ORDER BY appointment_date, appointment_time",
        (session["user_id"],), True
    )
    reports = execute(
        "SELECT * FROM reports WHERE user_id=? ORDER BY created_at DESC",
        (session["user_id"],), True
    )
    return render_template("dashboard.html", appointments=appointments, reports=reports)

@app.route("/checker", methods=["GET", "POST"])
def checker():
    if "user_id" not in session:
        return redirect(url_for("login"))
    prediction = None
    selected = []
    if request.method == "POST":
        selected = request.form.getlist("symptoms")
        prediction = predict_condition(selected)
        symptoms_text = ", ".join(s.replace("_", " ").title() for s in selected)
        execute(
            "INSERT INTO reports (user_id,symptoms,prediction,created_at) VALUES (?,?,?,?)",
            (session["user_id"], symptoms_text or "No symptoms selected",
             prediction, datetime.now().isoformat(timespec="seconds"))
        )
        flash("Preliminary health-check report generated.", "success")
    return render_template("checker.html", symptoms=SYMPTOMS, selected=selected, prediction=prediction)

@app.route("/appointment", methods=["GET", "POST"])
def appointment():
    if "user_id" not in session:
        return redirect(url_for("login"))
    if request.method == "POST":
        doctor = request.form.get("doctor", "").strip()
        date = request.form.get("appointment_date", "")
        time = request.form.get("appointment_time", "")
        if not doctor or not date or not time:
            flash("Please select doctor, date and time.", "danger")
        else:
            execute(
                "INSERT INTO appointments (user_id,doctor,appointment_date,appointment_time,created_at) VALUES (?,?,?,?,?)",
                (session["user_id"], doctor, date, time, datetime.now().isoformat(timespec="seconds"))
            )
            flash("Appointment booked successfully.", "success")
            return redirect(url_for("appointment"))
    appointments = execute(
        "SELECT * FROM appointments WHERE user_id=? ORDER BY appointment_date, appointment_time",
        (session["user_id"],), True
    )
    return render_template("appointment.html", appointments=appointments)

@app.route("/profile")
def profile():
    if "user_id" not in session:
        return redirect(url_for("login"))
    rows = execute("SELECT * FROM users WHERE id=?", (session["user_id"],), True)
    return render_template("profile.html", user=rows[0] if rows else None)

@app.route("/report")
def report():
    if "user_id" not in session:
        return redirect(url_for("login"))
    reports = execute(
        "SELECT * FROM reports WHERE user_id=? ORDER BY created_at DESC",
        (session["user_id"],), True
    )
    return render_template("report.html", reports=reports)

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    if request.method == "POST":
        flash("Thank you. Your message has been submitted.", "success")
        return redirect(url_for("contact"))
    return render_template("contact.html")

@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out successfully.", "success")
    return redirect(url_for("home"))

@app.context_processor
def inject_globals():
    return {"current_year": datetime.now().year}

init_db()

if __name__ == "__main__":
    app.run(debug=True)
