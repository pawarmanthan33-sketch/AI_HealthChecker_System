document.addEventListener("DOMContentLoaded", () => {
  const dateInput = document.querySelector('input[type="date"]');
  if (dateInput) dateInput.min = new Date().toISOString().split("T")[0];
  setTimeout(() => document.querySelectorAll(".alert").forEach(a => {
    a.style.transition = "opacity .4s"; a.style.opacity = "0";
  }), 5000);
});